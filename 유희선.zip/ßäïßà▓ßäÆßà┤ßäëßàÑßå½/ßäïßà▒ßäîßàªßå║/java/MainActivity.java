package com.example.appwidget_08;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        deleteDatabase("test.db");

        /* 테스트용 DB생성 */
        //DB생성
        String lv = "12";
        String exp = "Sun";
        String type = "2";
        String max_exp = "2000";
        String sql = "INSERT INTO people (lv,exp,type,max_exp) VALUES ("  +lv  +",'"  +exp  +"',"  +type +"," +max_exp +  ");" ;

        SQLiteDatabase db = openOrCreateDatabase("test.db",
                SQLiteDatabase.CREATE_IF_NECESSARY,
                null);
        db.execSQL("CREATE TABLE IF NOT EXISTS people"
                + "(_id INTEGER PRIMARY KEY AUTOINCREMENT,lv INTEGER, exp TEXT, type INTEGER, max_exp INTEGER);");

        db.execSQL(sql);

        if(db!=null){
            db.close();
        }
    }
}
