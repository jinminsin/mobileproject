package com.example.appwidget_08;

import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.Toast;

import androidx.annotation.Nullable;

//startService( onCreate()->onStartCommand() )
//bindService( onCreate()->onBind() )

public class appwidgetProvdier extends AppWidgetProvider {

    private static int data1;
    private static String data2;
    private static int data3;
    private static int data4;
    private static SQLiteDatabase db=null;

    public static  boolean endServiceFlag = false;
    private static int curCount=0;



////////서비스ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ
    public static class UpdateService extends Service implements Runnable  {
        private Handler mHandler;
        private static final int TIMER_PERIOD = 2*(1000); // 괄호안이 밀리세컨
        private long preTime;
        private long curTime;


        @Override
        public void onCreate() {
            super.onCreate();
            mHandler = new Handler();
        }

        @Override
        public int onStartCommand(Intent intent, int flags, int startId) {



            preTime = System.currentTimeMillis();
            mHandler.postDelayed(this,100);

            return START_NOT_STICKY;
        }

        @Override
        public boolean onUnbind(Intent intent) {
            Toast.makeText(this,"service Unbinded!",Toast.LENGTH_SHORT).show();
            return true;
        }


        @Nullable
        @Override
        public IBinder onBind(Intent intent) {
            return null;
        }


        @Override
        public void run() {

            db = SQLiteDatabase.openOrCreateDatabase("/data/data/com.example.appwidget_08/databases/test.db",
                    null);                                       //path : " /data/data/프로젝트명/databases/DB명 " 으로 하면됨

            Cursor c = db.rawQuery("SELECT * FROM people;",null); //쿼리문도 동일, 이건 수업때 했음
            c.moveToFirst();
            data1 = c.getInt(1);    //경험치를 칼럼인덱스 1로 가정함 //DB에 저장된 자료형에따라 getInt, getString 등으로 쓰시길
            data2 = c.getString(2); //레벨을 칼럼인덱스 2로 가정함
            data3 = c.getInt(3); //캐릭터 타입을 칼럼인덱스 3으로 가정함
            data4 = c.getInt(4); //max_exp를 칼럼인덱스 4로 가정함

            curTime = System.currentTimeMillis();
            ImageHelper imageHelper = new ImageHelper();
            RemoteViews views = new RemoteViews(this.getPackageName(),R.layout.appwidget_layout);

            long CUR_PERIOD = curTime -preTime;
            if(CUR_PERIOD>2000){
                views.setTextViewText(R.id.w_textView2,"exp : "+data2+"/"+data4); //경험치 뷰 설정
                views.setTextViewText(R.id.w_textView1,"레벨 "+data1); //레벨 뷰 설정

                /*캐릭터 이미지 뷰 설정*/
                if(data3 == 1){ //캐릭터 타입 1
                    if(curCount%3 == 0){ //조건 //지금은 2초단위로 변경되도록 해놨음. 레벨단위로 수정필요. 레벨은 data2
                        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.marin_lv1);
                        bitmap = imageHelper.getRoundedCornerBitmap(bitmap,120);
                        views.setImageViewBitmap(R.id.w_imageView1,bitmap);
                    }else if(curCount%3 == 1){
                        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.marin_lv2);
                        bitmap = imageHelper.getRoundedCornerBitmap(bitmap,120);
                        views.setImageViewBitmap(R.id.w_imageView1,bitmap);
                    }else if(curCount%3 == 2){
                        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.marin_lv3);
                        bitmap = imageHelper.getRoundedCornerBitmap(bitmap,120);
                        views.setImageViewBitmap(R.id.w_imageView1,bitmap);
                    }

                }
                else if(data3 == 2){ //캐릭터 타입 2
                    if(curCount%3 == 0){ //조건 //지금은 2초단위로 변경되도록 해놨음. 레벨단위로 수정필요. 레벨은 data2
                        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.frozen_lv1);
                        bitmap = imageHelper.getRoundedCornerBitmap(bitmap,120);
                        views.setImageViewBitmap(R.id.w_imageView1,bitmap);
                    }else if(curCount%3 == 1){
                        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.frozen_lv2);
                        bitmap = imageHelper.getRoundedCornerBitmap(bitmap,120);
                        views.setImageViewBitmap(R.id.w_imageView1,bitmap);
                    }else if(curCount%3 == 2){
                        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.frozen_lv3);
                        bitmap = imageHelper.getRoundedCornerBitmap(bitmap,120);
                        views.setImageViewBitmap(R.id.w_imageView1,bitmap);
                    }
                }
                else if(data3 == 3){ //캐릭터 타입 3
                    if(curCount%3 == 0){ //조건 //지금은 2초단위로 변경되도록 해놨음. 레벨단위로 수정필요. 레벨은 data2
                        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.santa_lv1);
                        bitmap = imageHelper.getRoundedCornerBitmap(bitmap,120);
                        views.setImageViewBitmap(R.id.w_imageView1,bitmap);
                    }else if(curCount%3 == 1){
                        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.santa_lv2);
                        bitmap = imageHelper.getRoundedCornerBitmap(bitmap,120);
                        views.setImageViewBitmap(R.id.w_imageView1,bitmap);
                    }else if(curCount%3 == 2){
                        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.santa_lv4);
                        bitmap = imageHelper.getRoundedCornerBitmap(bitmap,120);
                        views.setImageViewBitmap(R.id.w_imageView1,bitmap);
                    }
                }
                /*캐릭터 이미지 뷰 설정 끝*/

                preTime = curTime;
                curCount++;
            }

            //위젯업데이트
            AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
            ComponentName testWidge = new ComponentName(this,appwidgetProvdier.class);
            appWidgetManager.updateAppWidget(testWidge,views);

            if(endServiceFlag){
                return;
            }else{
                mHandler.postDelayed(this,TIMER_PERIOD);//TIMER_PERIOD에 지정된 초마다 갱신
            }


        }//run
    }//UpdateService


    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        super.onUpdate(context, appWidgetManager, appWidgetIds);

        Intent intent = new Intent(context,UpdateService.class);
        context.startService(intent);
        Log.i("onUpdate","서비스 실행됨");

    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
    }

    @Override
    public void onEnabled(final Context context) {
        super.onEnabled(context);
        //endServiceFlag = false;
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        //endServiceFlag = true;
//        i
    }

}
