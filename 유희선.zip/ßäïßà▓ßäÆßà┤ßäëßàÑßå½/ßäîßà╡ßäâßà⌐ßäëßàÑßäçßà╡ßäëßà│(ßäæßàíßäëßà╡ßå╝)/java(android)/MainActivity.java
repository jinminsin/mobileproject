package com.example.a11_googlemap_emptyactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;


import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback  {

    private GoogleMap mMap;
    double wp;
    double gp;
    String park="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



//        //산책길 DB
//        String sql = "INSERT INTO people (num,name,age) VALUES ("+num+",'"+name+"',"+age+");";
//
//        SQLiteDatabase db = openOrCreateDatabase("test.db",
//                SQLiteDatabase.CREATE_IF_NECESSARY,
//                null);
//        db.execSQL("CREATE TABLE IF NOT EXISTS people"
//                + "(_id INTEGER PRIMARY KEY AUTOINCREMENT,num INTEGER, name TEXT, age INTEGER);");
//
//        db.execSQL(sql);


//        try{
//            InputStream in = getResources().openRawResource(R.raw.test);
//            if(in != null){
//                InputStreamReader isr = new InputStreamReader(in,"utf-8");
//                BufferedReader bfr = new BufferedReader(isr);
//
//                String read;
//                StringBuilder sb = new StringBuilder("");
//
//                while( (read = bfr.readLine()) != null  ){
//                    sb.append(read);
//                }
//                in.close();
//
//                String x[] = sb.toString().split(" ");
//                ArrayList<String[]> list1 = new ArrayList<>();
//                //String y="";
//                int cnt =0;
//                int len = x.length;
//
//                for(String i : x){
//                    String y[] = i.split(",");
//                    list1.add(y);
//                }
////                for(String i : x){
////                    y+= i;
////                    y+=" ";
////                    cnt++;
////                }
//                for(String[] i : list1){
//                    park =i[0];
//                    wp = Double.parseDouble(i[1]);
//                    gp = Double.parseDouble(i[2]);
//                    Log.i("정보",""+park+" "+wp+" "+gp);
//
//                }
//
////                TextView txt = findViewById(R.id.textView1);
////                txt.setText(y);
//            }
//
//
//        }catch (Exception e){
//            e.printStackTrace();
//        }






        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        //
        try{
            InputStream in = getResources().openRawResource(R.raw.test);
            if(in != null){
                InputStreamReader isr = new InputStreamReader(in,"utf-8");
                BufferedReader bfr = new BufferedReader(isr);

                String read;
                StringBuilder sb = new StringBuilder("");

                while( (read = bfr.readLine()) != null  ){
                    sb.append(read);
                }
                in.close();

                String x[] = sb.toString().split(" ");
                ArrayList<String[]> list1 = new ArrayList<>();
//                String y="";
                int cnt =0;
                int len = x.length;

                for(String i : x){
                    String y[] = i.split(",");
                    list1.add(y);
                }
//                for(String i : x){
//                    if(cnt%2==1){
//                        y+= i;
//                    }
//                    cnt++;
//                }
                for(String[] i : list1){
                    park =i[0];
                    wp = Double.parseDouble(i[1]);
                    gp = Double.parseDouble(i[2]);
                    //Log.i("정보",""+park+" "+wp+" "+gp);
                    LatLng lng1 = new LatLng(wp,gp); //마커 찍을
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(lng1);
                    markerOptions.title(park);
                    //markerOptions.snippet("한국의 수도");
                    mMap.addMarker(markerOptions);
                }

//                TextView txt = findViewById(R.id.textView1);
//                txt.setText(y);
            }


        }catch (Exception e){
            e.printStackTrace();
        }










        ///








//

        LatLng SEOUL = new LatLng(wp,gp); //gps 현재 위치로 설정해야함
//        MarkerOptions markerOptions = new MarkerOptions();
//        markerOptions.position(SEOUL);
//        markerOptions.title("서울");
//        markerOptions.snippet("한국의 수도");
//        mMap.addMarker(markerOptions);

        mMap.moveCamera(CameraUpdateFactory.newLatLng(SEOUL)); //gps 현재 위치로 설정해야함
        mMap.animateCamera(CameraUpdateFactory.zoomTo(10));
    }
}
