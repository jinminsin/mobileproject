package file_parsing;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.io.BufferedWriter;
import java.io.FileWriter;

public class parsing {
	public static void main(String argv[]) {
		String filename = "./daguepark_total.txt";
		
		try {
			File wfile = new File(filename);
			FileWriter fw = new FileWriter(wfile,false); //true append
														//false write
			
			
			File file = new File("./대구_도시공원정보.xml");
			DocumentBuilderFactory docBuildFact = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuild = docBuildFact.newDocumentBuilder();
			Document doc = docBuild.parse(file);
			doc.getDocumentElement().normalize();
			
			NodeList parklist = doc.getElementsByTagName("공원명");
			NodeList gplist = doc.getElementsByTagName("경도");
			NodeList wplist = doc.getElementsByTagName("위도");
			for (int i = 0; i < parklist.getLength(); i++) {
				 
				System.out.println("---------- parkNode "+ i + "번째 ------------------");
 
				//공원명
				Element parkElmnt = (Element)parklist.item(i);
				Node park = parkElmnt.getFirstChild();
				fw.write(""+park.getNodeValue()+",");
				fw.flush();
				System.out.println(""+park.getNodeValue());
				
				//위도
				Element wpElmnt = (Element) wplist.item(i);
				Node wp = wpElmnt.getFirstChild();
				fw.write(""+wp.getNodeValue()+",");
				fw.flush();
				System.out.println(""+wp.getNodeValue());
				
				//경도
				Element gpElmnt = (Element) gplist.item(i);
				Node gp = gpElmnt.getFirstChild();
				fw.write(""+gp.getNodeValue()+" ");
				fw.flush();
				System.out.println(""+gp.getNodeValue());
				
				

 
				System.out.println("---------------------------------------------");
				System.out.println();
			}
			
			fw.close();
 

			
			
		}catch(Exception e){
			
		}
	}

}
